Dataset downloaded from: https://moleculenet.org/
